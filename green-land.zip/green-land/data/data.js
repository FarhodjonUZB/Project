const initialPlaces = [
  { id: '1', title: 'Toshkent', image: 'https://tashkent.uz/_next/image?url=https%3A%2F%2Fapi.tashkent.uz%2Fupload%2Fcity%2Fseesight%2F2025%2F%25D0%25A2%25D0%25B0%25D1%2588%25D0%25BA%25D0%25B5%25D0%25BD%25D1%2582%25D1%2581%25D0%25BA%25D0%25B0%25D1%258F_%25D0%25A2%25D0%25B5%25D0%25BB%25D0%25B5%25D0%25B1%25D0%25B0%25D1%2588%25D0%25BD%25D1%258F_Russian.jpg&w=3840&q=75', category: 'Tarix' },
  { id: '2', title: 'Buxoro', image: 'https://picsum.photos/id/1018/300/200', category: 'Tarix' },
  { id: '3', title: 'Samarqand', image: 'https://picsum.photos/id/1043/300/200', category: 'Tarix' },
  { id: '4', title: 'Qo‘qon', image: 'https://picsum.photos/id/1015/300/200', category: 'Tabiat' },
  { id: '5', title: 'Farg‘ona', image: 'https://picsum.photos/id/1018/300/200', category: 'Tabiat' },
];
