import React, { useState } from 'react';
import { 
  SafeAreaView, 
  View, 
  Text, 
  TextInput, 
  ScrollView, 
  Image, 
  StyleSheet, 
  TouchableOpacity, 
  Modal,
  Dimensions 
} from 'react-native';

const { width, height } = Dimensions.get('window');

const initialPlaces = [
  { 
    id: '1', 
    title: 'Toshkent', 
    image: 'https://tashkent.uz/_next/image?url=https%3A%2F%2Fapi.tashkent.uz%2Fupload%2Fcity%2Fseesight%2F2025%2F%25D0%25A2%25D0%25B0%25D1%2588%25D0%25BA%25D0%25B5%25D0%25BD%25D1%2582%25D1%2581%25D0%25BA%25D0%25B0%25D1%258F_%25D0%25A2%25D0%25B5%25D0%25BB%25D0%25B5%25D0%25B1%25D0%25B0%25D1%2588%25D0%25BD%25D1%258F_Russian.jpg&w=3840&q=75', 
    category: 'Olimov Farhodjon',
    ecoInfo: {
      airQuality: 'O‘rtacha (AQI: 85)',
      waterQuality: 'Yaxshi',
      greenZones: '15 ta park va bog‘lar',
      wasteManagement: 'Qoniqarli',
      temperature: '+24°C',
      humidity: '65%'
    }
  },
  { 
    id: '2', 
    title: 'Buxoro', 
    image: 'https://uzbekistan.travel/storage/app/media/Rasmlar/Buxoro/cropped-images/image_2024-12-23_16-38-28-0-0-0-0-1738740766.png', 
    category: 'Axmedov Ahadjon',
    ecoInfo: {
      airQuality: 'Yaxshi (AQI: 45)',
      waterQuality: 'Suv tanqisligi kuzatilmoqda',
      greenZones: '8 ta park va bog‘lar',
      wasteManagement: 'Yaxshi',
      temperature: '+28°C',
      humidity: '30%'
    }
  },
  { 
    id: '3', 
    title: 'Samarqand', 
    image: 'https://tourism.samdu.uz/assets/images/sam1.jpg', 
    category: 'Jakbarov Asliddin',
    ecoInfo: {
      airQuality: 'O‘rtacha (AQI: 72)',
      waterQuality: 'Yaxshi',
      greenZones: '20 ta park va bog‘lar',
      wasteManagement: 'Yaxshi',
      temperature: '+26°C',
      humidity: '45%'
    }
  },
  { 
    id: '4', 
    title: 'Qo‘qon', 
    image: 'https://uzbekistan.travel/storage/app/media/noviy/kokand-3.jpg', 
    category: 'Onarov Faroxiddin',
    ecoInfo: {
      airQuality: 'Qoniqarli (AQI: 95)',
      waterQuality: 'O‘rtacha',
      greenZones: '10 ta park va bog‘lar',
      wasteManagement: 'Yaxshilash talab etiladi',
      temperature: '+27°C',
      humidity: '50%'
    }
  },
  { 
    id: '5', 
    title: 'Farg‘ona', 
    image: 'https://yuz.uz/imageproxy/980x/https://yuz.uz/file/news/402a2677031ab9685b9aef0c6630f7cd.jpg', 
    category: 'Nabiyev Kamronmirzo',
    ecoInfo: {
      airQuality: 'Yaxshi (AQI: 55)',
      waterQuality: 'Yaxshi',
      greenZones: '25 ta park va bog‘lar',
      wasteManagement: 'Yaxshi',
      temperature: '+25°C',
      humidity: '55%'
    }
  },
];

export default function App() {
  const [search, setSearch] = useState('');
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const filtered = initialPlaces.filter(place =>
    place.title.toLowerCase().includes(search.toLowerCase())
  );

  const openModal = (place) => {
    setSelectedPlace(place);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedPlace(null);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* HEADER */}
      <View style={styles.header}>
        <Text style={styles.headerText}>🌍 Green Land</Text>
     <View>
      <Image
        style={{left: 280, width: 60, height: 60,bottom:20,borderRadius: 100 }} // Dimensions must be specified
        source={{
          uri: 'https://t4.ftcdn.net/jpg/02/58/74/53/360_F_258745363_DMK4GAbMtgxFr5SymK137NaCytoP6ndA.jpg', // The URI is inside the source object
        }}
      />
    </View>
      </View>

      {/* SEARCHBAR */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Qidirish..."
          value={search}
          onChangeText={setSearch}
        />
      </View>
    
      <View style={styles.yozuv}> 
        <Text style={styles.matn}>Hududlar:</Text>
      </View>

      {/* SCROLL VIEW WITH CARDS */}
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {filtered.map(place => (
          <TouchableOpacity 
            key={place.id} 
            style={styles.card} 
            onPress={() => openModal(place)}
          >
            <Image source={{ uri: place.image }} style={styles.image} />
            <View style={styles.cardContent}>
              <Text style={styles.title}>{place.title}</Text>
              <Text style={styles.category}>{place.category}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* MODAL FOR ECOLOGICAL INFORMATION */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={closeModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {selectedPlace && (
              <>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>
                    {selectedPlace.title} - Ekologik Ma'lumotlar
                  </Text>
                  <TouchableOpacity onPress={closeModal} style={styles.closeButton}>
                    <Text style={styles.closeButtonText}>✕</Text>
                  </TouchableOpacity>
                </View>

                <ScrollView style={styles.modalBody}>
                  <Image source={{ uri: selectedPlace.image }} style={styles.modalImage} />
                  
                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>🌍 Mas'ul shaxs:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.category}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>🌫 Havo sifati:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.airQuality}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>💧 Suv sifati:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.waterQuality}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>🌳 Yashil zonalar:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.greenZones}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>🗑 Chiqindi boshqaruvi:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.wasteManagement}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>🌡 Harorat:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.temperature}</Text>
                  </View>

                  <View style={styles.infoSection}>
                    <Text style={styles.infoLabel}>💧 Namlik:</Text>
                    <Text style={styles.infoValue}>{selectedPlace.ecoInfo.humidity}</Text>
                  </View>
                </ScrollView>

                <TouchableOpacity style={styles.modalButton} onPress={closeModal}>
                  <Text style={styles.modalButtonText}>Yopish</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* FOOTER */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>© 2026 Ecology App</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#f5f5f5' 
  },
  header: { 
    height: 80, 
    backgroundColor: '#2e7d32', 
    justifyContent: 'center', 
    paddingHorizontal: 20 
  },
  headerText: { 
    color: '#fff', 
    fontSize: 28, 
    fontWeight: 'bold',
    top: 25 
  },
  searchContainer: { 
    padding: 16 
  },
  searchInput: { 
    backgroundColor: '#fff', 
    borderRadius: 30, 
    padding: 12, 
    fontSize: 16, 
    borderWidth: 1, 
    borderColor: '#ddd' 
  },
  scrollContent: { 
    paddingHorizontal: 16, 
    paddingBottom: 20 
  },
  card: { 
    flexDirection: 'row', 
    backgroundColor: '#fff', 
    borderRadius: 20, 
    marginBottom: 12, 
    overflow: 'hidden', 
    shadowColor: '#000', 
    shadowOpacity: 0.1, 
    shadowRadius: 5, 
    elevation: 3 
  },
  image: { 
    width: 100, 
    height: 100 
  },
  cardContent: { 
    flex: 1, 
    padding: 12, 
    justifyContent: 'center' 
  },
  title: { 
    fontSize: 18, 
    fontWeight: '600', 
    marginBottom: 4,
    color: '#2e7d32'
  },
  category: { 
    fontSize: 14, 
    color: '#666' 
  },
  footer: { 
    height: 50, 
    backgroundColor: '#eee', 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  footerText: { 
    fontSize: 14, 
    color: '#333' 
  },
  yozuv: { 
    marginHorizontal: 25,
    marginBottom: 10,
  },
  matn: { 
    fontWeight: 'bold',
    fontSize: 17,
    color: '#2e7d32'
  },
  
  // Modal stillari
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: width * 0.9,
    maxHeight: height * 0.8,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingBottom: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2e7d32',
    flex: 1,
  },
  closeButton: {
    padding: 8,
  },
  closeButtonText: {
    fontSize: 20,
    color: '#666',
    fontWeight: 'bold',
  },
  modalBody: {
    maxHeight: height * 0.5,
  },
  modalImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 15,
  },
  infoSection: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  infoLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2e7d32',
    width: '40%',
  },
  infoValue: {
    fontSize: 15,
    color: '#333',
    width: '60%',
  },
  modalButton: {
    backgroundColor: '#2e7d32',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 15,
  },
  modalButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});